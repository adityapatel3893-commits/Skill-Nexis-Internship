const notFound = (req, res) => {
  res.status(404).json({ error: `Route not found: ${req.method} ${req.originalUrl}` });
};

// eslint-disable-next-line no-unused-vars
const errorHandler = (err, req, res, next) => {
  // Mongoose validation error (e.g. missing title)
  if (err.name === 'ValidationError') {
    const details = {};
    Object.values(err.errors).forEach((e) => { details[e.path] = e.message; });
    return res.status(400).json({ status: 400, error: 'Validation failed', details });
  }

  // Invalid MongoDB ObjectId in the URL
  if (err.name === 'CastError') {
    return res.status(400).json({ status: 400, error: `Invalid id: ${err.value}` });
  }

  // Malformed JSON body
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ status: 400, error: 'Invalid JSON body' });
  }

  console.error(err);
  res.status(500).json({ status: 500, error: 'Internal server error' });
};

module.exports = { notFound, errorHandler };
