const express = require('express');
const controller = require('../controllers/taskController');

const router = express.Router();

router.route('/')
  .get(controller.getAllTasks)
  .post(controller.addTask);

router.route('/:id')
  .get(controller.getTask)
  .put(controller.updateTask)
  .delete(controller.deleteTask);

router.patch('/:id/complete', controller.completeTask);

module.exports = router;
