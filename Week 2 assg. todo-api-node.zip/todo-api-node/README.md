# To-Do List REST API

A REST API for managing tasks, built with **Node.js, Express and MongoDB (Mongoose)**, tested with **Postman**.

## Features

- Add, update, delete and view tasks
- Mark a task as completed
- Input validation (title is required)
- Proper HTTP status codes and JSON error messages
- MongoDB for data storage

## Tech stack

| Layer | Technology |
|---|---|
| Runtime | Node.js 18+ |
| Framework | Express 4 |
| Database | MongoDB with Mongoose |
| API testing | Postman |

## Prerequisites

- Node.js 18 or newer
- MongoDB running locally, or a free MongoDB Atlas cluster
- Postman

## Setup and run

```bash
git clone <your-repo-url>
cd todo-api
npm install
cp .env.example .env      # on Windows: copy .env.example .env
npm run dev               # auto-restart with nodemon
# or: npm start
```

The API runs at `http://localhost:3000`. Edit `.env` to change the port or use MongoDB Atlas.

## API endpoints

Base URL: `http://localhost:3000/api/tasks`

| Method | Endpoint | Description | Success response |
|---|---|---|---|
| POST | `/api/tasks` | Add a task | 201 Created |
| GET | `/api/tasks` | Get all tasks | 200 OK |
| GET | `/api/tasks/:id` | Get one task | 200 OK |
| PUT | `/api/tasks/:id` | Update a task | 200 OK |
| PATCH | `/api/tasks/:id/complete` | Mark task completed | 200 OK |
| DELETE | `/api/tasks/:id` | Delete a task | 204 No Content |

Error responses: `400` for a missing title or invalid id, `404` when the task does not exist.

### Task JSON

```json
{
  "title": "Buy milk",
  "description": "2 litres",
  "completed": false
}
```

## Testing with Postman

1. Open Postman and click **Import**.
2. Select `postman/ToDo-API.postman_collection.json`.
3. Make sure the server is running, then click the collection's **Run** button.

The collection runs the requests in order (add, validate, get, update, complete, delete, confirm 404). The task id is saved automatically between requests by the test scripts. Add your own screenshots to a `screenshots/` folder for your submission.

## Project structure

```
todo-api/
├── server.js
├── package.json
├── .env.example
├── README.md
├── postman/ToDo-API.postman_collection.json
└── src/
    ├── config/db.js
    ├── controllers/taskController.js
    ├── middleware/errorHandler.js
    ├── models/Task.js
    └── routes/taskRoutes.js
```

## Uploading to GitHub

```bash
git init
git add .
git commit -m "To-Do List REST API with Node.js, Express and MongoDB"
git branch -M main
git remote add origin https://github.com/<your-username>/todo-api.git
git push -u origin main
```

The `.gitignore` keeps `node_modules` and your `.env` file (which may hold database credentials) out of the repo.
