require('dotenv').config();
const express = require('express');
const cors = require('cors');

const connectDB = require('./src/config/db');
const authRoutes = require('./src/routes/authRoutes');
const taskRoutes = require('./src/routes/taskRoutes');
const uploadRoutes = require('./src/routes/uploadRoutes');
const { UPLOAD_DIR } = require('./src/middleware/upload');
const { notFound, errorHandler } = require('./src/middleware/errorHandler');

if (!process.env.JWT_SECRET) {
  console.error('Missing JWT_SECRET. Copy .env.example to .env and set it.');
  process.exit(1);
}

const app = express();

app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));
app.use(express.json());

// Uploaded images are served as static files: GET /uploads/<filename>
app.use('/uploads', express.static(UPLOAD_DIR));

app.get('/', (req, res) => {
  res.json({
    message: 'To-Do List API is running',
    endpoints: ['/api/auth', '/api/tasks', '/api/upload']
  });
});

app.use('/api/auth', authRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/upload', uploadRoutes);

app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 3000;

connectDB().then(() => {
  app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
});
