const jwt = require('jsonwebtoken');
const User = require('../models/User');

const signToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d'
  });

const sendAuth = (res, status, user) =>
  res.status(status).json({ token: signToken(user.id), user });

// POST /api/auth/register
exports.register = async (req, res, next) => {
  try {
    const { name, email, password } = req.body;
    const user = await User.create({ name, email, password });
    sendAuth(res, 201, user);
  } catch (err) {
    next(err);
  }
};

// POST /api/auth/login
exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ status: 400, error: 'Email and password are required' });
    }

    const user = await User.findOne({ email: String(email).toLowerCase().trim() }).select('+password');
    // Same message for "no such user" and "wrong password" so attackers can't probe emails
    if (!user || !(await user.matchPassword(password))) {
      return res.status(401).json({ status: 401, error: 'Invalid email or password' });
    }

    sendAuth(res, 200, user);
  } catch (err) {
    next(err);
  }
};

// GET /api/auth/me  (protected)
exports.me = (req, res) => {
  res.json({ user: req.user });
};
