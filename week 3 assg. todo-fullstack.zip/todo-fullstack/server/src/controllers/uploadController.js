const fs = require('fs/promises');
const path = require('path');
const Image = require('../models/Image');
const Task = require('../models/Task');
const { UPLOAD_DIR } = require('../middleware/upload');

const removeFile = async (filename) => {
  try {
    await fs.unlink(path.join(UPLOAD_DIR, path.basename(filename)));
  } catch (err) {
    if (err.code !== 'ENOENT') throw err; // already gone is fine
  }
};

// POST /api/upload - upload one image (multipart/form-data, field name "image")
exports.uploadImage = async (req, res, next) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        status: 400,
        error: 'No file uploaded. Send an image in the "image" form field'
      });
    }

    const image = await Image.create({
      user: req.user.id,
      filename: req.file.filename,
      originalName: req.file.originalname,
      mimetype: req.file.mimetype,
      size: req.file.size,
      url: `/uploads/${req.file.filename}`
    });

    res.status(201).json(image);
  } catch (err) {
    // Don't leave an orphan file on disk if saving the record failed
    if (req.file) await removeFile(req.file.filename).catch(() => {});
    next(err);
  }
};

// GET /api/upload - list the current user's images
exports.getImages = async (req, res, next) => {
  try {
    const images = await Image.find({ user: req.user.id }).sort({ createdAt: -1 });
    res.json(images);
  } catch (err) {
    next(err);
  }
};

// DELETE /api/upload/:id - delete an image (file + record) and detach it from tasks
exports.deleteImage = async (req, res, next) => {
  try {
    const image = await Image.findOneAndDelete({ _id: req.params.id, user: req.user.id });
    if (!image) return res.status(404).json({ error: 'Image not found' });

    await removeFile(image.filename);
    await Task.updateMany({ user: req.user.id, image: image.url }, { image: '' });

    res.status(204).send();
  } catch (err) {
    next(err);
  }
};
