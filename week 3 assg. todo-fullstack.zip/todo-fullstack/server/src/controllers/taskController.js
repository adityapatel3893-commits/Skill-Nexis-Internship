const Task = require('../models/Task');
const Image = require('../models/Image');

// Every query below is scoped to req.user so users can only touch their own tasks.

// Returns an error message if `image` is not one of the user's uploaded images
const checkImage = async (image, userId) => {
  if (!image) return null;
  const owned = await Image.exists({ url: image, user: userId });
  return owned ? null : 'Image not found. Upload it first via POST /api/upload';
};

// GET /api/tasks - list the current user's tasks
exports.getAllTasks = async (req, res, next) => {
  try {
    const tasks = await Task.find({ user: req.user.id }).sort({ createdAt: -1 });
    res.json(tasks);
  } catch (err) {
    next(err);
  }
};

// GET /api/tasks/:id - get one task
exports.getTask = async (req, res, next) => {
  try {
    const task = await Task.findOne({ _id: req.params.id, user: req.user.id });
    if (!task) return res.status(404).json({ error: 'Task not found' });
    res.json(task);
  } catch (err) {
    next(err);
  }
};

// POST /api/tasks - add a task
exports.addTask = async (req, res, next) => {
  try {
    const { title, description, completed, image } = req.body;

    const imageError = await checkImage(image, req.user.id);
    if (imageError) return res.status(400).json({ status: 400, error: imageError });

    const task = await Task.create({
      user: req.user.id,
      title,
      description,
      completed,
      image
    });
    res.status(201).json(task);
  } catch (err) {
    next(err);
  }
};

// PUT /api/tasks/:id - update a task (only the fields that are sent)
exports.updateTask = async (req, res, next) => {
  try {
    const updates = {};
    ['title', 'description', 'completed', 'image'].forEach((field) => {
      if (req.body[field] !== undefined) updates[field] = req.body[field];
    });

    if (updates.image !== undefined) {
      const imageError = await checkImage(updates.image, req.user.id);
      if (imageError) return res.status(400).json({ status: 400, error: imageError });
    }

    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id },
      updates,
      { new: true, runValidators: true }
    );
    if (!task) return res.status(404).json({ error: 'Task not found' });
    res.json(task);
  } catch (err) {
    next(err);
  }
};

// PATCH /api/tasks/:id/complete - mark a task as completed
exports.completeTask = async (req, res, next) => {
  try {
    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id },
      { completed: true },
      { new: true }
    );
    if (!task) return res.status(404).json({ error: 'Task not found' });
    res.json(task);
  } catch (err) {
    next(err);
  }
};

// DELETE /api/tasks/:id - delete a task
exports.deleteTask = async (req, res, next) => {
  try {
    const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.user.id });
    if (!task) return res.status(404).json({ error: 'Task not found' });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
};
