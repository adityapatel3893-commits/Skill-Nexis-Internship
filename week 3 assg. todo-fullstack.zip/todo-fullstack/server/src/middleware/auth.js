const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Protects a route: requires "Authorization: Bearer <token>"
const protect = async (req, res, next) => {
  try {
    const header = req.headers.authorization || '';
    const [scheme, token] = header.split(' ');

    if (scheme !== 'Bearer' || !token) {
      return res.status(401).json({ status: 401, error: 'Not authorized: token missing' });
    }

    let payload;
    try {
      payload = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      return res.status(401).json({ status: 401, error: 'Not authorized: invalid or expired token' });
    }

    const user = await User.findById(payload.id);
    if (!user) {
      return res.status(401).json({ status: 401, error: 'Not authorized: user no longer exists' });
    }

    req.user = user;
    next();
  } catch (err) {
    next(err);
  }
};

module.exports = { protect };
