const multer = require('multer');

const notFound = (req, res) => {
  res.status(404).json({ error: `Route not found: ${req.method} ${req.originalUrl}` });
};

// eslint-disable-next-line no-unused-vars
const errorHandler = (err, req, res, next) => {
  // Mongoose validation error (e.g. missing title)
  if (err.name === 'ValidationError') {
    const details = {};
    Object.values(err.errors).forEach((e) => { details[e.path] = e.message; });
    return res.status(400).json({ status: 400, error: 'Validation failed', details });
  }

  // Invalid MongoDB ObjectId in the URL
  if (err.name === 'CastError') {
    return res.status(400).json({ status: 400, error: `Invalid id: ${err.value}` });
  }

  // Duplicate key (e.g. email already registered)
  if (err.code === 11000) {
    const field = Object.keys(err.keyPattern || {})[0] || 'value';
    return res.status(409).json({ status: 409, error: `That ${field} is already in use` });
  }

  // Multer errors (file too large, unexpected field, ...)
  if (err instanceof multer.MulterError) {
    const message =
      err.code === 'LIMIT_FILE_SIZE'
        ? 'File is too large (max 5 MB)'
        : err.code === 'LIMIT_UNEXPECTED_FILE'
          ? 'Unexpected file field: use the field name "image"'
          : err.message;
    return res.status(400).json({ status: 400, error: message });
  }

  // Wrong file type rejected by our fileFilter
  if (err.name === 'UploadTypeError') {
    return res.status(400).json({ status: 400, error: err.message });
  }

  // Malformed JSON body
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ status: 400, error: 'Invalid JSON body' });
  }

  console.error(err);
  res.status(500).json({ status: 500, error: 'Internal server error' });
};

module.exports = { notFound, errorHandler };
