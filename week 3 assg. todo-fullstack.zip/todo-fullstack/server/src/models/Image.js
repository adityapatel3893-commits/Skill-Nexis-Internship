const mongoose = require('mongoose');

const imageSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true
    },
    filename: { type: String, required: true }, // name on disk
    originalName: { type: String, required: true },
    mimetype: { type: String, required: true },
    size: { type: Number, required: true }, // bytes
    url: { type: String, required: true } // public path, e.g. /uploads/<filename>
  },
  { timestamps: true }
);

imageSchema.set('toJSON', {
  transform: (doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    delete ret.__v;
    delete ret.user;
    return ret;
  }
});

module.exports = mongoose.model('Image', imageSchema);
