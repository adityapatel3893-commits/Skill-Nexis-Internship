const express = require('express');
const controller = require('../controllers/taskController');
const { protect } = require('../middleware/auth');

const router = express.Router();

// Every task route requires a valid JWT
router.use(protect);

router.route('/')
  .get(controller.getAllTasks)
  .post(controller.addTask);

router.route('/:id')
  .get(controller.getTask)
  .put(controller.updateTask)
  .delete(controller.deleteTask);

router.patch('/:id/complete', controller.completeTask);

module.exports = router;
