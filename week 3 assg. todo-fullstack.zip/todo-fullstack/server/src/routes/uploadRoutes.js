const express = require('express');
const controller = require('../controllers/uploadController');
const { protect } = require('../middleware/auth');
const { upload } = require('../middleware/upload');

const router = express.Router();

router.use(protect);

router.route('/')
  .get(controller.getImages)
  // upload.single('image') -> Multer parses the "image" field into req.file
  .post(upload.single('image'), controller.uploadImage);

router.delete('/:id', controller.deleteImage);

module.exports = router;
