import { useEffect, useState } from 'react';
import { deleteImage, fetchImages, getErrorMessage, imageUrl, uploadImage } from '../api.js';
import ImagePicker from '../components/ImagePicker.jsx';

const formatSize = (bytes) =>
  bytes >= 1024 * 1024 ? `${(bytes / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`;

export default function Images() {
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [file, setFile] = useState(null);
  const [progress, setProgress] = useState(0);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchImages()
      .then(setImages)
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  const handleUpload = async () => {
    if (!file) return;
    setUploading(true);
    setProgress(0);
    setError('');
    try {
      const saved = await uploadImage(file, setProgress);
      setImages((prev) => [saved, ...prev]);
      setFile(null);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (image) => {
    if (!window.confirm(`Delete ${image.originalName}? Tasks using it will lose the image.`)) return;
    setError('');
    try {
      await deleteImage(image.id);
      setImages((prev) => prev.filter((i) => i.id !== image.id));
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  return (
    <div>
      <h1>Image library</h1>
      <p className="muted">Choose an image to preview it, then upload it to the server.</p>

      <div className="card upload-card">
        <ImagePicker file={file} onChange={setFile} disabled={uploading} />

        {uploading && (
          <div className="progress" aria-label="Upload progress">
            <div className="progress-bar" style={{ width: `${progress}%` }} />
          </div>
        )}

        <button className="btn btn-primary" onClick={handleUpload} disabled={!file || uploading}>
          {uploading ? `Uploading… ${progress}%` : 'Upload image'}
        </button>
      </div>

      {error && <p className="error">{error}</p>}

      <div className="section-head">
        <h2>Uploaded images</h2>
        <span className="muted">{images.length} total</span>
      </div>

      {loading && <p className="muted">Loading images…</p>}
      {!loading && images.length === 0 && <div className="empty">No images uploaded yet.</div>}

      <div className="gallery">
        {images.map((image) => (
          <figure key={image.id} className="card gallery-item">
            <a href={imageUrl(image.url)} target="_blank" rel="noreferrer">
              <img src={imageUrl(image.url)} alt={image.originalName} loading="lazy" />
            </a>
            <figcaption>
              <span className="filename" title={image.originalName}>{image.originalName}</span>
              <span className="muted small">{formatSize(image.size)}</span>
              <button className="btn btn-danger-ghost btn-sm" onClick={() => handleDelete(image)}>Delete</button>
            </figcaption>
          </figure>
        ))}
      </div>
    </div>
  );
}
