import { useEffect, useMemo, useState } from 'react';
import { fetchTasks, getErrorMessage } from '../api.js';
import TaskForm from '../components/TaskForm.jsx';
import TaskItem from '../components/TaskItem.jsx';

const FILTERS = [
  { key: 'all', label: 'All' },
  { key: 'active', label: 'Active' },
  { key: 'completed', label: 'Completed' }
];

export default function Tasks() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchTasks()
      .then(setTasks)
      .catch((err) => setError(getErrorMessage(err)))
      .finally(() => setLoading(false));
  }, []);

  const handleCreated = (task) => setTasks((prev) => [task, ...prev]);
  const handleChanged = (task) => setTasks((prev) => prev.map((t) => (t.id === task.id ? task : t)));
  const handleDeleted = (id) => setTasks((prev) => prev.filter((t) => t.id !== id));

  const visible = useMemo(() => {
    if (filter === 'active') return tasks.filter((t) => !t.completed);
    if (filter === 'completed') return tasks.filter((t) => t.completed);
    return tasks;
  }, [tasks, filter]);

  const doneCount = tasks.filter((t) => t.completed).length;

  return (
    <div className="two-col">
      <aside>
        <TaskForm onCreated={handleCreated} />
      </aside>

      <section>
        <div className="section-head">
          <h2>Your tasks</h2>
          <span className="muted">{doneCount} of {tasks.length} done</span>
        </div>

        <div className="tabs" role="tablist">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              role="tab"
              aria-selected={filter === f.key}
              className={filter === f.key ? 'tab active' : 'tab'}
              onClick={() => setFilter(f.key)}
            >
              {f.label}
            </button>
          ))}
        </div>

        {loading && <p className="muted">Loading tasks…</p>}
        {error && <p className="error">{error}</p>}

        {!loading && !error && visible.length === 0 && (
          <div className="empty">
            {tasks.length === 0 ? 'No tasks yet. Add your first one!' : 'Nothing in this view.'}
          </div>
        )}

        <ul className="task-list">
          {visible.map((task) => (
            <TaskItem key={task.id} task={task} onChanged={handleChanged} onDeleted={handleDeleted} />
          ))}
        </ul>
      </section>
    </div>
  );
}
