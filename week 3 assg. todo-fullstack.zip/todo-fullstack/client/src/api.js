import axios from 'axios';

// Empty in development (Vite proxy). Set VITE_API_URL for a deployed build.
export const API_URL = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');

const TOKEN_KEY = 'todo_token';
export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (token) => localStorage.setItem(TOKEN_KEY, token);
export const clearToken = () => localStorage.removeItem(TOKEN_KEY);

const api = axios.create({ baseURL: `${API_URL}/api` });

// Attach the JWT to every request
api.interceptors.request.use((config) => {
  const token = getToken();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// If the server says our token is invalid/expired, log the user out.
// (Login/register 401s are normal "wrong password" errors, so skip those.)
api.interceptors.response.use(
  (res) => res,
  (err) => {
    const url = err.config?.url || '';
    if (err.response?.status === 401 && !url.startsWith('/auth/login') && !url.startsWith('/auth/register')) {
      clearToken();
      window.dispatchEvent(new Event('auth:logout'));
    }
    return Promise.reject(err);
  }
);

// Turn an Axios error into a readable message
export const getErrorMessage = (err) => {
  const data = err.response?.data;
  if (data?.details) return Object.values(data.details).join('. ');
  if (data?.error) return data.error;
  if (err.code === 'ERR_NETWORK') return 'Cannot reach the server. Is it running?';
  return err.message || 'Something went wrong';
};

// Full URL for an image path returned by the API (e.g. "/uploads/abc.png")
export const imageUrl = (path) => {
  if (!path) return '';
  return /^https?:\/\//.test(path) ? path : `${API_URL}${path}`;
};

// ---- Auth ----
export const registerUser = (data) => api.post('/auth/register', data).then((r) => r.data);
export const loginUser = (data) => api.post('/auth/login', data).then((r) => r.data);
export const fetchMe = () => api.get('/auth/me').then((r) => r.data.user);

// ---- Tasks (CRUD) ----
export const fetchTasks = () => api.get('/tasks').then((r) => r.data);
export const createTask = (data) => api.post('/tasks', data).then((r) => r.data);
export const updateTask = (id, data) => api.put(`/tasks/${id}`, data).then((r) => r.data);
export const deleteTask = (id) => api.delete(`/tasks/${id}`);

// ---- Images (Multer endpoint) ----
export const fetchImages = () => api.get('/upload').then((r) => r.data);
export const deleteImage = (id) => api.delete(`/upload/${id}`);
export const uploadImage = (file, onProgress) => {
  const form = new FormData();
  form.append('image', file); // field name must match upload.single('image') on the server
  return api
    .post('/upload', form, {
      onUploadProgress: (e) => {
        if (onProgress && e.total) onProgress(Math.round((e.loaded * 100) / e.total));
      }
    })
    .then((r) => r.data);
};

export default api;
