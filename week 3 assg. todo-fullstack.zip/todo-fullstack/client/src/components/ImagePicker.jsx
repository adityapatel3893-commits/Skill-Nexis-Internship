import { useEffect, useRef, useState } from 'react';
import { imageUrl } from '../api.js';

const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
const MAX_SIZE = 5 * 1024 * 1024; // keep in sync with the server limit (5 MB)

/**
 * Lets the user choose an image and shows a preview *before* anything is uploaded.
 *
 *  file             – the File chosen by the user (or null)
 *  onChange         – called with a File, or null when removed
 *  existingUrl      – path of an image that is already saved (shown if no new file)
 *  onRemoveExisting – called when the user removes the already-saved image
 */
export default function ImagePicker({ file, onChange, existingUrl = '', onRemoveExisting, disabled = false }) {
  const inputRef = useRef(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const [error, setError] = useState('');

  // Build a temporary browser URL for the chosen file, and free it when no longer needed
  useEffect(() => {
    if (!file) {
      setPreviewUrl('');
      return undefined;
    }
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const handleSelect = (e) => {
    const selected = e.target.files?.[0];
    e.target.value = ''; // allow picking the same file again later
    if (!selected) return;

    if (!ALLOWED_TYPES.includes(selected.type)) {
      setError('Please choose a JPG, PNG, GIF or WEBP image.');
      return;
    }
    if (selected.size > MAX_SIZE) {
      setError('That image is larger than 5 MB.');
      return;
    }
    setError('');
    onChange(selected);
  };

  const handleRemove = () => {
    setError('');
    if (file) onChange(null);
    else if (onRemoveExisting) onRemoveExisting();
  };

  const shown = previewUrl || imageUrl(existingUrl);

  return (
    <div className="image-picker">
      <input
        ref={inputRef}
        type="file"
        accept={ALLOWED_TYPES.join(',')}
        onChange={handleSelect}
        disabled={disabled}
        hidden
      />

      {shown ? (
        <div className="preview">
          <img src={shown} alt="Selected preview" />
          <div className="preview-actions">
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => inputRef.current.click()} disabled={disabled}>
              Change
            </button>
            <button type="button" className="btn btn-danger-ghost btn-sm" onClick={handleRemove} disabled={disabled}>
              Remove
            </button>
          </div>
          {file && <p className="muted small">{file.name} · {(file.size / 1024).toFixed(0)} KB · not uploaded yet</p>}
        </div>
      ) : (
        <button type="button" className="dropzone" onClick={() => inputRef.current.click()} disabled={disabled}>
          <span className="dropzone-icon">🖼️</span>
          <span>Click to choose an image</span>
          <span className="muted small">JPG, PNG, GIF or WEBP · up to 5 MB</span>
        </button>
      )}

      {error && <p className="error small">{error}</p>}
    </div>
  );
}
