import { useState } from 'react';
import { deleteTask, getErrorMessage, imageUrl, updateTask, uploadImage } from '../api.js';
import ImagePicker from './ImagePicker.jsx';

export default function TaskItem({ task, onChanged, onDeleted }) {
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(task.title);
  const [description, setDescription] = useState(task.description);
  const [file, setFile] = useState(null); // newly chosen image
  const [removeImage, setRemoveImage] = useState(false); // user removed the saved image
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const run = async (fn) => {
    setBusy(true);
    setError('');
    try {
      await fn();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const toggleComplete = () =>
    run(async () => onChanged(await updateTask(task.id, { completed: !task.completed })));

  const handleDelete = () => {
    if (!window.confirm(`Delete "${task.title}"?`)) return;
    run(async () => {
      await deleteTask(task.id);
      onDeleted(task.id);
    });
  };

  const startEdit = () => {
    setTitle(task.title);
    setDescription(task.description);
    setFile(null);
    setRemoveImage(false);
    setError('');
    setEditing(true);
  };

  const handleSave = (e) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Title cannot be empty.');
      return;
    }
    run(async () => {
      const changes = { title, description };
      if (file) changes.image = (await uploadImage(file)).url;
      else if (removeImage) changes.image = '';
      onChanged(await updateTask(task.id, changes));
      setEditing(false);
    });
  };

  if (editing) {
    return (
      <li className="card task editing">
        <form onSubmit={handleSave}>
          <label>
            Title
            <input value={title} onChange={(e) => setTitle(e.target.value)} disabled={busy} autoFocus />
          </label>
          <label>
            Description
            <textarea rows="2" value={description} onChange={(e) => setDescription(e.target.value)} disabled={busy} />
          </label>
          <div>
            <span className="label-text">Image</span>
            <ImagePicker
              file={file}
              onChange={setFile}
              existingUrl={removeImage ? '' : task.image}
              onRemoveExisting={() => setRemoveImage(true)}
              disabled={busy}
            />
          </div>
          {error && <p className="error">{error}</p>}
          <div className="row">
            <button className="btn btn-primary btn-sm" disabled={busy}>{busy ? 'Saving…' : 'Save'}</button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => setEditing(false)} disabled={busy}>
              Cancel
            </button>
          </div>
        </form>
      </li>
    );
  }

  return (
    <li className={`card task ${task.completed ? 'done' : ''}`}>
      <input
        type="checkbox"
        className="check"
        checked={task.completed}
        onChange={toggleComplete}
        disabled={busy}
        aria-label={`Mark "${task.title}" as ${task.completed ? 'not completed' : 'completed'}`}
      />

      <div className="task-body">
        <h3>{task.title}</h3>
        {task.description && <p>{task.description}</p>}
        {task.image && (
          <a href={imageUrl(task.image)} target="_blank" rel="noreferrer">
            <img className="task-img" src={imageUrl(task.image)} alt={`Attachment for ${task.title}`} loading="lazy" />
          </a>
        )}
        <p className="muted small">Added {new Date(task.createdAt).toLocaleDateString()}</p>
        {error && <p className="error small">{error}</p>}
      </div>

      <div className="task-actions">
        <button className="btn btn-ghost btn-sm" onClick={startEdit} disabled={busy}>Edit</button>
        <button className="btn btn-danger-ghost btn-sm" onClick={handleDelete} disabled={busy}>Delete</button>
      </div>
    </li>
  );
}
