import { useState } from 'react';
import { createTask, getErrorMessage, uploadImage } from '../api.js';
import ImagePicker from './ImagePicker.jsx';

export default function TaskForm({ onCreated }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [file, setFile] = useState(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Please enter a title.');
      return;
    }

    setSaving(true);
    setError('');
    try {
      // 1) upload the image (if any), 2) create the task that points to it
      let image = '';
      if (file) {
        const uploaded = await uploadImage(file);
        image = uploaded.url;
      }
      const task = await createTask({ title, description, image });
      onCreated(task);
      setTitle('');
      setDescription('');
      setFile(null);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <form className="card task-form" onSubmit={handleSubmit}>
      <h2>Add a task</h2>

      <label>
        Title
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Finish the React assignment" disabled={saving} />
      </label>

      <label>
        Description <span className="muted">(optional)</span>
        <textarea rows="2" value={description} onChange={(e) => setDescription(e.target.value)} disabled={saving} />
      </label>

      <div>
        <span className="label-text">Image <span className="muted">(optional)</span></span>
        <ImagePicker file={file} onChange={setFile} disabled={saving} />
      </div>

      {error && <p className="error">{error}</p>}

      <button className="btn btn-primary" disabled={saving}>
        {saving ? 'Saving…' : 'Add task'}
      </button>
    </form>
  );
}
