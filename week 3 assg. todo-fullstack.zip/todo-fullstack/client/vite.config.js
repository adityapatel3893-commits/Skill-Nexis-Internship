import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// In development the React app (5173) proxies API calls and image requests to
// the Express server (3000), so there are no CORS issues and no URLs to change.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': 'http://localhost:3000',
      '/uploads': 'http://localhost:3000'
    }
  }
});
