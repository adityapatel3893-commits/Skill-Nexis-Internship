# TaskBoard – Full Stack To-Do Application

A full stack to-do app built on the Week 2 REST API.
**React** (Vite) frontend · **Express + MongoDB** backend · **JWT authentication** · **Multer image uploads**.

## Assignment checklist

| Requirement | Where it is |
|---|---|
| Connect Week 2 API with React frontend | `client/src/api.js` (Axios) calls the Express API in `server/` |
| Authentication | Register / login / logout with bcrypt-hashed passwords and JWT (`server/src/controllers/authController.js`, `client/src/context/AuthContext.jsx`) |
| CRUD functionality | Create, read, update (edit + toggle complete) and delete tasks (`client/src/pages/Tasks.jsx`, `client/src/components/TaskItem.jsx`) |
| Routing | React Router: `/`, `/images`, `/login`, `/register`, 404, with protected and public-only routes (`client/src/App.jsx`) |
| File upload endpoint with Multer | `POST /api/upload` (`server/src/middleware/upload.js`, `server/src/controllers/uploadController.js`) |
| Preview and display uploaded images | Live preview before upload (`client/src/components/ImagePicker.jsx`), gallery page (`client/src/pages/Images.jsx`), images on task cards |

## Features

- Sign up, log in, log out; the session survives page refresh
- Each user only sees and edits **their own** tasks and images
- Add, edit, complete/uncomplete and delete tasks; filter All / Active / Completed
- Attach an image to a task
- Image library page with upload progress bar, gallery and delete
- Client and server validation (file type, 5 MB limit, required fields)
- Responsive layout with automatic dark mode

## Tech stack

| Layer | Technology |
|---|---|
| Frontend | React 18, Vite, React Router 6, Axios |
| Backend | Node.js 18+, Express 4 |
| Database | MongoDB with Mongoose |
| Auth | JSON Web Tokens (`jsonwebtoken`), `bcryptjs` |
| Uploads | Multer (disk storage) |
| API testing | Postman |

## Project structure

```
todo-fullstack/
├── README.md
├── package.json              # convenience scripts (install:all, server, client)
├── screenshots/              # add your screenshots here for submission
├── server/                   # Express API (the Week 2 project, extended)
│   ├── server.js
│   ├── .env.example
│   ├── uploads/              # uploaded images are saved here (git-ignored)
│   ├── postman/ToDo-FullStack-API.postman_collection.json
│   └── src/
│       ├── config/db.js
│       ├── models/           # User.js, Task.js, Image.js
│       ├── middleware/       # auth.js (JWT), upload.js (Multer), errorHandler.js
│       ├── controllers/      # authController.js, taskController.js, uploadController.js
│       └── routes/           # authRoutes.js, taskRoutes.js, uploadRoutes.js
└── client/                   # React app
    ├── index.html
    ├── vite.config.js        # dev proxy to the API
    └── src/
        ├── main.jsx, App.jsx, api.js, styles.css
        ├── context/AuthContext.jsx
        ├── components/       # Navbar, RouteGuards, ImagePicker, TaskForm, TaskItem
        └── pages/            # Login, Register, Tasks, Images, NotFound
```

## Getting started

### Prerequisites

- Node.js 18 or newer
- MongoDB running locally, **or** a free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster

### 1. Install

```bash
git clone <your-repo-url>
cd todo-fullstack
npm run install:all
```

### 2. Configure the server

```bash
cd server
cp .env.example .env      # on Windows: copy .env.example .env
```

Open `server/.env` and set:

- `MONGODB_URI` – local MongoDB or your Atlas connection string
- `JWT_SECRET` – any long random string. Generate one with:
  `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`

The client needs no configuration in development.

### 3. Run (two terminals)

```bash
# Terminal 1 – API on http://localhost:3000
npm run server

# Terminal 2 – React app on http://localhost:5173
npm run client
```

Open **http://localhost:5173**, create an account and start adding tasks.

> In development Vite proxies `/api` and `/uploads` to the Express server, so there are no CORS or URL settings to change.

## API reference

Base URL: `http://localhost:3000`. All routes except register/login require the header
`Authorization: Bearer <token>`.

### Auth

| Method | Endpoint | Description | Success |
|---|---|---|---|
| POST | `/api/auth/register` | Create account `{ name, email, password }` | 201 `{ token, user }` |
| POST | `/api/auth/login` | Log in `{ email, password }` | 200 `{ token, user }` |
| GET | `/api/auth/me` | Current user | 200 `{ user }` |

### Tasks

| Method | Endpoint | Description | Success |
|---|---|---|---|
| POST | `/api/tasks` | Add a task | 201 |
| GET | `/api/tasks` | List my tasks | 200 |
| GET | `/api/tasks/:id` | Get one task | 200 |
| PUT | `/api/tasks/:id` | Update (only the fields you send) | 200 |
| PATCH | `/api/tasks/:id/complete` | Mark completed | 200 |
| DELETE | `/api/tasks/:id` | Delete | 204 |

Task JSON:

```json
{
  "title": "Buy milk",
  "description": "2 litres",
  "completed": false,
  "image": "/uploads/1730000000000-a1b2c3d4e5f6.png"
}
```

### Image upload (Multer)

| Method | Endpoint | Description | Success |
|---|---|---|---|
| POST | `/api/upload` | Upload one image (`multipart/form-data`, field name **`image`**) | 201 |
| GET | `/api/upload` | List my uploaded images | 200 |
| DELETE | `/api/upload/:id` | Delete the file and its record; removes it from any task using it | 204 |
| GET | `/uploads/<filename>` | Serve an uploaded image (static) | 200 |

Upload rules: JPG, PNG, GIF or WEBP only, max 5 MB. File names are randomised on the server and the extension is taken from the verified MIME type.

Errors: `400` validation / bad file, `401` missing or invalid token, `404` not found, `409` email already registered.

## How the image upload works

1. The user picks a file in `ImagePicker`; the browser shows an instant preview using `URL.createObjectURL`.
2. On submit, the client sends it as `FormData` (field `image`) to `POST /api/upload`.
3. Multer validates the type and size and writes the file to `server/uploads/`.
4. The API saves an `Image` record and returns its `url` (e.g. `/uploads/…png`).
5. The client stores that URL on the task (`image`) and renders it with an `<img>` tag; Express serves the file statically.

## Testing with Postman

1. Import `server/postman/ToDo-FullStack-API.postman_collection.json`.
2. Start the server, then run the folders in order: **Auth → Tasks → Image upload → Cleanup**.
3. The login request saves the token automatically. For **Upload image**, open the request, go to *Body → form-data* and choose an image file for the `image` field before sending.

## Uploading to GitHub

Create an empty repository on github.com first (no README), then from the project root:

```bash
git init
git add .
git commit -m "Full stack To-Do app: React frontend, JWT auth, CRUD, Multer image upload"
git branch -M main
git remote add origin https://github.com/<your-username>/todo-fullstack.git
git push -u origin main
```

`.gitignore` keeps `node_modules`, your `.env` (database credentials and JWT secret) and uploaded images out of the repository. Before pushing, run `git status` and confirm no `.env` file is listed.

## Troubleshooting

| Problem | Fix |
|---|---|
| `MongoDB connection failed` | Start MongoDB, or check `MONGODB_URI` (Atlas: allow your IP in Network Access) |
| `Missing JWT_SECRET` | Create `server/.env` from `.env.example` |
| Login works but pages keep redirecting to `/login` | The token is invalid or expired; log in again. Make sure `JWT_SECRET` did not change |
| Images do not show | Confirm the API is running on port 3000 (the Vite proxy forwards `/uploads`) |
| Port already in use | Change `PORT` in `server/.env` **and** the proxy targets in `client/vite.config.js` |

## Deploying (optional)

Deploy `server/` to a Node host (e.g. Render) with the same environment variables, setting `CLIENT_URL` to your frontend's URL. Build the client with `VITE_API_URL=<your API URL>` set, and host `client/dist` on a static host (e.g. Netlify or Vercel). Note that many free hosts have an ephemeral disk, so uploaded files can disappear on restart; use cloud storage (S3, Cloudinary) for production.

## License

MIT
