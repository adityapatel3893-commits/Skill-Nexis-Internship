import axios from 'axios';

// Empty in development (Vite proxy). Set VITE_API_URL for a deployed build.
export const API_URL = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');

const TOKEN_KEY = 'taskwise_token';
export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (token) => localStorage.setItem(TOKEN_KEY, token);
export const clearToken = () => localStorage.removeItem(TOKEN_KEY);

const api = axios.create({ baseURL: `${API_URL}/api` });

// Attach the JWT to every request
api.interceptors.request.use((config) => {
  const token = getToken();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// If the server rejects our token, log the user out.
// (Login/register 401s are normal "wrong password" errors, so skip those.)
api.interceptors.response.use(
  (res) => res,
  (err) => {
    const url = err.config?.url || '';
    if (err.response?.status === 401 && !url.startsWith('/auth/login') && !url.startsWith('/auth/register')) {
      clearToken();
      window.dispatchEvent(new Event('auth:logout'));
    }
    return Promise.reject(err);
  }
);

// Turn an Axios error into a readable message
export const getErrorMessage = (err) => {
  const data = err.response?.data;
  if (data?.details) return Object.values(data.details).join('. ');
  if (data?.error) return data.error;
  if (err.code === 'ERR_NETWORK') return 'Cannot reach the server. Check that the API is running.';
  return err.message || 'Something went wrong';
};

// ---- Auth ----
export const registerUser = (data) => api.post('/auth/register', data).then((r) => r.data);
export const loginUser = (data) => api.post('/auth/login', data).then((r) => r.data);
export const fetchMe = () => api.get('/auth/me').then((r) => r.data.user);

// ---- Tasks ----
// params: { status, priority, due, search, sort, today }; empty values are dropped by Axios
export const fetchTasks = (params) => api.get('/tasks', { params }).then((r) => r.data);
export const fetchStats = (today) => api.get('/tasks/stats', { params: { today } }).then((r) => r.data);
export const createTask = (data) => api.post('/tasks', data).then((r) => r.data);
export const updateTask = (id, data) => api.put(`/tasks/${id}`, data).then((r) => r.data);
export const deleteTask = (id) => api.delete(`/tasks/${id}`);

export default api;
