import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { createTask, deleteTask, fetchStats, fetchTasks, getErrorMessage, updateTask } from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';
import Sidebar from '../components/Sidebar.jsx';
import TaskRow from '../components/TaskRow.jsx';
import TaskModal from '../components/TaskModal.jsx';
import { todayStr } from '../utils/dates.js';

const VIEWS = ['today', 'overdue', 'week'];
const STATUSES = ['todo', 'in-progress', 'done'];
const PRIORITIES = ['high', 'medium', 'low'];
const SORTS = [
  { value: 'newest', label: 'Newest first' },
  { value: 'oldest', label: 'Oldest first' },
  { value: 'due', label: 'Due date' },
  { value: 'priority', label: 'Priority' }
];
const VIEW_TITLES = { '': 'All tasks', today: 'Due today', overdue: 'Overdue', week: 'Next 7 days' };

// Accept only known values from the URL
const allowed = (value, list, fallback = '') => (list.includes(value) ? value : fallback);

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const today = todayStr();

  // Filters live in the URL (?view=overdue&status=todo&priority=high&q=react&sort=due),
  // so they survive a refresh and can be shared or bookmarked.
  const filters = {
    view: allowed(searchParams.get('view'), VIEWS),
    status: allowed(searchParams.get('status'), STATUSES),
    priority: allowed(searchParams.get('priority'), PRIORITIES)
  };
  const sort = allowed(searchParams.get('sort'), SORTS.map((s) => s.value), 'newest');
  const urlSearch = searchParams.get('q') || '';
  const hasFilters = Boolean(filters.view || filters.status || filters.priority || urlSearch.trim());

  const setParam = (key, value, replace = false) => {
    setSearchParams(
      (prev) => {
        const next = new URLSearchParams(prev);
        if (value) next.set(key, value);
        else next.delete(key);
        return next;
      },
      { replace }
    );
  };

  // Search box: type freely, update the URL (and the list) after a short pause
  const [searchText, setSearchText] = useState(urlSearch);
  useEffect(() => setSearchText(urlSearch), [urlSearch]); // follows back/forward and "Clear filters"
  useEffect(() => {
    if (searchText === urlSearch) return undefined;
    const timer = setTimeout(() => setParam('q', searchText.trim() ? searchText : '', true), 300);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchText, urlSearch]);

  // ---- data ----
  const [tasks, setTasks] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actionError, setActionError] = useState('');
  const [busyId, setBusyId] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);
  const reload = () => setReloadKey((k) => k + 1);

  // Only send filters that have a value
  const params = { today, sort };
  if (filters.view) params.due = filters.view;
  if (filters.status) params.status = filters.status;
  if (filters.priority) params.priority = filters.priority;
  if (urlSearch.trim()) params.search = urlSearch.trim();
  const paramsKey = JSON.stringify(params);

  useEffect(() => {
    let cancelled = false;
    fetchTasks(JSON.parse(paramsKey))
      .then((data) => {
        if (cancelled) return;
        setTasks(data);
        setError('');
      })
      .catch((err) => !cancelled && setError(getErrorMessage(err)))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [paramsKey, reloadKey]);

  useEffect(() => {
    let cancelled = false;
    fetchStats(today)
      .then((data) => !cancelled && setStats(data))
      .catch(() => {}); // counts are a nice-to-have; the list shows real errors
    return () => {
      cancelled = true;
    };
  }, [reloadKey, today]);

  // ---- actions ----
  const [modal, setModal] = useState(null); // null, or { task } (task is null for "new")

  const handleSave = async (data) => {
    if (modal.task) await updateTask(modal.task.id, data);
    else await createTask(data);
    setModal(null);
    reload();
  };

  const runOnTask = async (task, fn) => {
    setBusyId(task.id);
    setActionError('');
    try {
      await fn();
      reload();
    } catch (err) {
      setActionError(getErrorMessage(err));
    } finally {
      setBusyId(null);
    }
  };

  const handleStatusChange = (task, status) => runOnTask(task, () => updateTask(task.id, { status }));

  const handleDelete = (task) => {
    if (!window.confirm(`Delete "${task.title}"? This cannot be undone.`)) return;
    runOnTask(task, () => deleteTask(task.id));
  };

  const clearFilters = () => setSearchParams(sort === 'newest' ? {} : { sort });

  return (
    <div className="app">
      <Sidebar stats={stats} filters={filters} onSelect={(key, value) => setParam(key, value)} user={user} onLogout={logout} />

      <main className="main">
        <div className="main-inner">
          <header className="page-head">
            <div>
              <h1>{VIEW_TITLES[filters.view]}</h1>
              <p className="muted">
                {loading ? 'Loading…' : `${tasks.length} ${tasks.length === 1 ? 'task' : 'tasks'} shown`}
                {hasFilters && (
                  <>
                    {' '}
                    <button type="button" className="link-btn" onClick={clearFilters}>Clear filters</button>
                  </>
                )}
              </p>
            </div>
            <button type="button" className="btn btn-primary" onClick={() => setModal({ task: null })}>New task</button>
          </header>

          <div className="toolbar">
            <input
              type="search"
              className="search"
              placeholder="Search titles and notes"
              aria-label="Search tasks"
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
            />
            <label className="sort">
              Sort by
              <select value={sort} onChange={(e) => setParam('sort', e.target.value === 'newest' ? '' : e.target.value)}>
                {SORTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>
            </label>
          </div>

          {error && <p className="error" role="alert">{error}</p>}
          {actionError && <p className="error" role="alert">{actionError}</p>}

          {!loading && !error && tasks.length === 0 && (
            <div className="empty">
              {hasFilters ? (
                <>
                  <p>No tasks match these filters.</p>
                  <button type="button" className="btn btn-secondary" onClick={clearFilters}>Clear filters</button>
                </>
              ) : (
                <>
                  <p>You have no tasks yet. Add one to start tracking your work.</p>
                  <button type="button" className="btn btn-primary" onClick={() => setModal({ task: null })}>Add your first task</button>
                </>
              )}
            </div>
          )}

          {tasks.length > 0 && (
            <ul className="task-list">
              {tasks.map((task) => (
                <TaskRow
                  key={task.id}
                  task={task}
                  today={today}
                  busy={busyId === task.id}
                  onStatusChange={handleStatusChange}
                  onEdit={(t) => setModal({ task: t })}
                  onDelete={handleDelete}
                />
              ))}
            </ul>
          )}
        </div>
      </main>

      {modal && <TaskModal task={modal.task} onClose={() => setModal(null)} onSave={handleSave} />}
    </div>
  );
}
