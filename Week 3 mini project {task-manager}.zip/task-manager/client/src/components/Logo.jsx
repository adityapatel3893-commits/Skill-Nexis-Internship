// Small checkmark mark used in the sidebar and on the sign-in pages
export default function Logo({ size = 28 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
      <rect width="64" height="64" rx="14" fill="#FFC93C" />
      <path d="M18 33l10 10 19-22" fill="none" stroke="#0E2A47" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
