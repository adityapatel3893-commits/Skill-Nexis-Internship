import { describeDue } from '../utils/dates.js';

const PRIORITY_LABEL = { high: 'High priority', medium: 'Medium priority', low: 'Low priority' };

export const STATUS_OPTIONS = [
  { value: 'todo', label: 'To do' },
  { value: 'in-progress', label: 'In progress' },
  { value: 'done', label: 'Done' }
];

export default function TaskRow({ task, today, busy, onStatusChange, onEdit, onDelete }) {
  const done = task.status === 'done';
  const due = describeDue(task.dueDate, task.status, today);

  return (
    <li className={`task-row priority-${task.priority}${done ? ' is-done' : ''}`}>
      <input
        type="checkbox"
        className="task-check"
        checked={done}
        disabled={busy}
        onChange={() => onStatusChange(task, done ? 'todo' : 'done')}
        aria-label={done ? `Mark "${task.title}" as not done` : `Mark "${task.title}" as done`}
      />

      <div className="task-main">
        <p className="task-title">{task.title}</p>
        {task.description && <p className="task-desc">{task.description}</p>}
        <div className="task-meta">
          <span className="chip chip-priority">{PRIORITY_LABEL[task.priority]}</span>
          {due && <span className={`chip chip-due ${due.tone}`}>{due.text}</span>}
        </div>
      </div>

      <div className="task-side">
        <select
          className="status-select"
          data-status={task.status}
          value={task.status}
          disabled={busy}
          onChange={(e) => onStatusChange(task, e.target.value)}
          aria-label={`Status of "${task.title}"`}
        >
          {STATUS_OPTIONS.map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
        <div className="task-buttons">
          <button type="button" className="link-btn" onClick={() => onEdit(task)} disabled={busy}>Edit</button>
          <button type="button" className="link-btn danger" onClick={() => onDelete(task)} disabled={busy}>Delete</button>
        </div>
      </div>
    </li>
  );
}
