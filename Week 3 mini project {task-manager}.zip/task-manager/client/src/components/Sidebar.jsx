import Logo from './Logo.jsx';

// Each group is a single-choice filter. Clicking the active item again clears it.
const GROUPS = [
  {
    key: 'view',
    title: 'Due dates',
    items: [
      { value: '', label: 'All tasks', count: (s) => s.total },
      { value: 'today', label: 'Due today', count: (s) => s.dueToday },
      { value: 'overdue', label: 'Overdue', count: (s) => s.overdue, alert: true },
      { value: 'week', label: 'Next 7 days', count: (s) => s.dueWeek }
    ]
  },
  {
    key: 'status',
    title: 'Status',
    items: [
      { value: 'todo', label: 'To do', count: (s) => s.todo },
      { value: 'in-progress', label: 'In progress', count: (s) => s.inProgress },
      { value: 'done', label: 'Done', count: (s) => s.done }
    ]
  },
  {
    key: 'priority',
    title: 'Priority',
    items: [
      { value: 'high', label: 'High', count: (s) => s.high },
      { value: 'medium', label: 'Medium', count: (s) => s.medium },
      { value: 'low', label: 'Low', count: (s) => s.low }
    ]
  }
];

export default function Sidebar({ stats, filters, onSelect, user, onLogout }) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <Logo />
        <span>Taskwise</span>
      </div>

      {GROUPS.map((group) => (
        <nav key={group.key} className="side-group" aria-label={group.title}>
          <h2 className="side-heading">{group.title}</h2>
          <ul>
            {group.items.map((item) => {
              const active = filters[group.key] === item.value;
              const count = stats ? item.count(stats) : null;
              const isAlert = item.alert && count > 0;
              return (
                <li key={item.value || 'all'}>
                  <button
                    type="button"
                    className={`side-item${active ? ' active' : ''}`}
                    aria-pressed={active}
                    onClick={() => onSelect(group.key, active ? '' : item.value)}
                  >
                    <span>{item.label}</span>
                    {count !== null && <span className={`count${isAlert ? ' count-alert' : ''}`}>{count}</span>}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>
      ))}

      <div className="side-user">
        <div className="side-user-text">
          <strong>{user.name}</strong>
          <span>{user.email}</span>
        </div>
        <button type="button" className="side-logout" onClick={onLogout}>Log out</button>
      </div>
    </aside>
  );
}
