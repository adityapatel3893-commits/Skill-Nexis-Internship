import Logo from './Logo.jsx';

// Shared frame for the login and register pages
export default function AuthLayout({ title, subtitle, children, footer }) {
  return (
    <div className="auth-page">
      <section className="auth-panel">
        <div className="brand">
          <Logo />
          <span>Taskwise</span>
        </div>
        <h1>See what is due before it is late.</h1>
        <ul>
          <li>Filter tasks by status, priority and due date.</li>
          <li>Spot overdue work the moment you sign in.</li>
          <li>Your tasks are private to your account.</li>
        </ul>
      </section>

      <section className="auth-form-wrap">
        <div className="auth-form">
          <h2>{title}</h2>
          <p className="muted">{subtitle}</p>
          {children}
          <p className="auth-footer">{footer}</p>
        </div>
      </section>
    </div>
  );
}
