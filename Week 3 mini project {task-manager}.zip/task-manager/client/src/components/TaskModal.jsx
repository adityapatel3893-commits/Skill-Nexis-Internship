import { useEffect, useState } from 'react';
import { getErrorMessage } from '../api.js';
import { STATUS_OPTIONS } from './TaskRow.jsx';

const PRIORITY_OPTIONS = [
  { value: 'high', label: 'High' },
  { value: 'medium', label: 'Medium' },
  { value: 'low', label: 'Low' }
];

// Add / edit dialog. `task` is null when creating a new one.
// onSave(data) must return a promise; the parent closes the dialog when it resolves.
export default function TaskModal({ task, onClose, onSave }) {
  const isEdit = Boolean(task);
  const [title, setTitle] = useState(task?.title || '');
  const [description, setDescription] = useState(task?.description || '');
  const [status, setStatus] = useState(task?.status || 'todo');
  const [priority, setPriority] = useState(task?.priority || 'medium');
  const [dueDate, setDueDate] = useState(task?.dueDate || '');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  // Close with the Escape key
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Enter a title for the task.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      await onSave({ title, description, status, priority, dueDate });
    } catch (err) {
      setError(getErrorMessage(err));
      setSaving(false);
    }
  };

  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal" role="dialog" aria-modal="true" aria-labelledby="task-modal-title">
        <h2 id="task-modal-title">{isEdit ? 'Edit task' : 'New task'}</h2>

        <form onSubmit={handleSubmit}>
          <label>
            Title
            <input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} autoFocus disabled={saving} />
          </label>

          <label>
            Notes <span className="muted">(optional)</span>
            <textarea rows="3" value={description} onChange={(e) => setDescription(e.target.value)} maxLength={1000} disabled={saving} />
          </label>

          <div className="form-grid">
            <label>
              Status
              <select value={status} onChange={(e) => setStatus(e.target.value)} disabled={saving}>
                {STATUS_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </label>
            <label>
              Priority
              <select value={priority} onChange={(e) => setPriority(e.target.value)} disabled={saving}>
                {PRIORITY_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </label>
            <label>
              Due date
              <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} disabled={saving} />
            </label>
          </div>

          {error && <p className="error" role="alert">{error}</p>}

          <div className="modal-actions">
            <button type="button" className="btn btn-secondary" onClick={onClose} disabled={saving}>Cancel</button>
            <button className="btn btn-primary" disabled={saving}>
              {saving ? 'Saving…' : isEdit ? 'Save changes' : 'Add task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
