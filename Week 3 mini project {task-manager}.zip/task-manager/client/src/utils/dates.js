// Due dates are plain "YYYY-MM-DD" strings, matching the API.

const pad = (n) => String(n).padStart(2, '0');

// Today's date in the user's own time zone
export const todayStr = () => {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};

const toUtcDay = (str) => {
  const [y, m, d] = str.split('-').map(Number);
  return Date.UTC(y, m - 1, d);
};

export const daysBetween = (from, to) => Math.round((toUtcDay(to) - toUtcDay(from)) / 86400000);

const short = (str, today) => {
  const [y, m, d] = str.split('-').map(Number);
  const sameYear = str.slice(0, 4) === today.slice(0, 4);
  return new Date(y, m - 1, d).toLocaleDateString(undefined, {
    day: 'numeric',
    month: 'short',
    ...(sameYear ? {} : { year: 'numeric' })
  });
};

// Text and tone ("overdue" | "soon" | "normal") for the due-date chip on a task
export const describeDue = (dueDate, status, today) => {
  if (!dueDate) return null;
  if (status === 'done') return { text: `Was due ${short(dueDate, today)}`, tone: 'normal' };

  const diff = daysBetween(today, dueDate);
  if (diff < 0) return { text: `Overdue since ${short(dueDate, today)}`, tone: 'overdue' };
  if (diff === 0) return { text: 'Due today', tone: 'soon' };
  if (diff === 1) return { text: 'Due tomorrow', tone: 'soon' };
  return { text: `Due ${short(dueDate, today)}`, tone: 'normal' };
};
