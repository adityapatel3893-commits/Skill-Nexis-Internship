// Pure helper functions for task filtering and sorting.
// They have no dependencies, so they can be unit tested without a database.
//
// Due dates are stored as plain "YYYY-MM-DD" strings (not Date objects). That avoids
// time-zone bugs: "due today" means the same calendar day for the user and the server,
// and strings in this format compare correctly with < and >.

const STATUSES = ['todo', 'in-progress', 'done'];
const PRIORITIES = ['low', 'medium', 'high'];
const SORTS = ['newest', 'oldest', 'due', 'priority'];

const isValidDate = (value) => {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const d = new Date(`${value}T00:00:00Z`);
  // Round-trip check rejects impossible dates such as 2026-02-30
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === value;
};

const addDays = (dateStr, days) => {
  const d = new Date(`${dateStr}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
};

// The browser sends its own local date as ?today=YYYY-MM-DD so "today" matches the user's
// time zone. Fall back to the server's date if it is missing or invalid.
const resolveToday = (value) => (isValidDate(value) ? value : new Date().toISOString().slice(0, 10));

const escapeRegex = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/**
 * Build a MongoDB filter from the query string.
 *   ?status=todo|in-progress|done
 *   ?priority=low|medium|high
 *   ?due=overdue|today|week      (overdue / today / week only include unfinished tasks,
 *                                 unless a status filter is chosen explicitly)
 *   ?search=text                 (matches title or description, case-insensitive)
 *   ?today=YYYY-MM-DD            (the client's local date)
 * Unknown values are ignored instead of causing errors.
 */
const buildTaskFilter = (query, userId) => {
  const filter = { user: userId };

  if (STATUSES.includes(query.status)) filter.status = query.status;
  if (PRIORITIES.includes(query.priority)) filter.priority = query.priority;

  const today = resolveToday(query.today);
  const openOnly = () => {
    if (!filter.status) filter.status = { $ne: 'done' };
  };

  switch (query.due) {
    case 'overdue':
      // "Overdue" is unfinished work, so asking for overdue + done matches nothing
      if (filter.status === 'done') filter.status = { $in: [] };
      else openOnly();
      filter.dueDate = { $gt: '', $lt: today }; // $gt '' skips tasks that have no due date
      break;
    case 'today':
      openOnly();
      filter.dueDate = today;
      break;
    case 'week':
      openOnly();
      filter.dueDate = { $gte: today, $lte: addDays(today, 7) };
      break;
    default:
      break;
  }

  const search = typeof query.search === 'string' ? query.search.trim().slice(0, 100) : '';
  if (search) {
    const regex = new RegExp(escapeRegex(search), 'i');
    filter.$or = [{ title: regex }, { description: regex }];
  }

  return filter;
};

const PRIORITY_RANK = { high: 0, medium: 1, low: 2 };
const time = (task) => new Date(task.createdAt).getTime();
const newestFirst = (a, b) => time(b) - time(a);

// Returns a new, sorted array. Sorting is done in memory because one user's task list is small.
const sortTasks = (tasks, sort) => {
  const list = [...tasks];
  switch (sort) {
    case 'oldest':
      return list.sort((a, b) => time(a) - time(b));
    case 'due':
      // soonest first; tasks without a due date go last
      return list.sort((a, b) => {
        if (a.dueDate && b.dueDate) return a.dueDate.localeCompare(b.dueDate) || newestFirst(a, b);
        if (a.dueDate) return -1;
        if (b.dueDate) return 1;
        return newestFirst(a, b);
      });
    case 'priority':
      return list.sort((a, b) => PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority] || newestFirst(a, b));
    default:
      return list.sort(newestFirst);
  }
};

module.exports = {
  STATUSES,
  PRIORITIES,
  SORTS,
  isValidDate,
  addDays,
  resolveToday,
  escapeRegex,
  buildTaskFilter,
  sortTasks
};
