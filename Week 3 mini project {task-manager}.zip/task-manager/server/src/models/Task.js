const mongoose = require('mongoose');
const { STATUSES, PRIORITIES, isValidDate } = require('../utils/taskFilters');

const taskSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true
    },
    title: {
      type: String,
      required: [true, 'Title is required'],
      trim: true,
      maxlength: [120, 'Title must be at most 120 characters']
    },
    description: {
      type: String,
      trim: true,
      default: '',
      maxlength: [1000, 'Description must be at most 1000 characters']
    },
    status: {
      type: String,
      enum: { values: STATUSES, message: 'Status must be one of: todo, in-progress, done' },
      default: 'todo'
    },
    priority: {
      type: String,
      enum: { values: PRIORITIES, message: 'Priority must be one of: low, medium, high' },
      default: 'medium'
    },
    // "YYYY-MM-DD", or an empty string when the task has no due date
    dueDate: {
      type: String,
      default: '',
      validate: {
        validator: (value) => value === '' || isValidDate(value),
        message: 'Due date must be a valid date in YYYY-MM-DD format'
      }
    }
  },
  { timestamps: true }
);

taskSchema.set('toJSON', {
  transform: (doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    delete ret.__v;
    delete ret.user;
    return ret;
  }
});

module.exports = mongoose.model('Task', taskSchema);
