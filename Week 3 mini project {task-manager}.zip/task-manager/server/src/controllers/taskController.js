const Task = require('../models/Task');
const { buildTaskFilter, sortTasks, resolveToday, addDays } = require('../utils/taskFilters');

// Every query is scoped to req.user so users can only touch their own tasks.

const EDITABLE_FIELDS = ['title', 'description', 'status', 'priority', 'dueDate'];

// Copy only the fields a client is allowed to set (and only the ones it actually sent)
const pickFields = (body) => {
  const data = {};
  EDITABLE_FIELDS.forEach((field) => {
    if (body[field] !== undefined) data[field] = body[field];
  });
  return data;
};

// GET /api/tasks?status=&priority=&due=&search=&sort=&today=
exports.getAllTasks = async (req, res, next) => {
  try {
    const tasks = await Task.find(buildTaskFilter(req.query, req.user.id));
    res.json(sortTasks(tasks, req.query.sort));
  } catch (err) {
    next(err);
  }
};

// GET /api/tasks/stats?today=YYYY-MM-DD - counts that power the sidebar
exports.getStats = async (req, res, next) => {
  try {
    const today = resolveToday(req.query.today);
    const mine = { user: req.user.id };
    const open = { ...mine, status: { $ne: 'done' } };

    const [total, todo, inProgress, done, overdue, dueToday, dueWeek, high, medium, low] = await Promise.all([
      Task.countDocuments(mine),
      Task.countDocuments({ ...mine, status: 'todo' }),
      Task.countDocuments({ ...mine, status: 'in-progress' }),
      Task.countDocuments({ ...mine, status: 'done' }),
      Task.countDocuments({ ...open, dueDate: { $gt: '', $lt: today } }),
      Task.countDocuments({ ...open, dueDate: today }),
      Task.countDocuments({ ...open, dueDate: { $gte: today, $lte: addDays(today, 7) } }),
      Task.countDocuments({ ...mine, priority: 'high' }),
      Task.countDocuments({ ...mine, priority: 'medium' }),
      Task.countDocuments({ ...mine, priority: 'low' })
    ]);

    res.json({ total, todo, inProgress, done, overdue, dueToday, dueWeek, high, medium, low });
  } catch (err) {
    next(err);
  }
};

// GET /api/tasks/:id
exports.getTask = async (req, res, next) => {
  try {
    const task = await Task.findOne({ _id: req.params.id, user: req.user.id });
    if (!task) return res.status(404).json({ error: 'Task not found' });
    res.json(task);
  } catch (err) {
    next(err);
  }
};

// POST /api/tasks
exports.addTask = async (req, res, next) => {
  try {
    const task = await Task.create({ ...pickFields(req.body), user: req.user.id });
    res.status(201).json(task);
  } catch (err) {
    next(err);
  }
};

// PUT /api/tasks/:id - update only the fields that are sent
exports.updateTask = async (req, res, next) => {
  try {
    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id },
      pickFields(req.body),
      { new: true, runValidators: true }
    );
    if (!task) return res.status(404).json({ error: 'Task not found' });
    res.json(task);
  } catch (err) {
    next(err);
  }
};

// DELETE /api/tasks/:id
exports.deleteTask = async (req, res, next) => {
  try {
    const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.user.id });
    if (!task) return res.status(404).json({ error: 'Task not found' });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
};
