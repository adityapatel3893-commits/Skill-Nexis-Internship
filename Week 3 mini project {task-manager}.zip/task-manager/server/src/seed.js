// Fills the database with a demo account and sample tasks (handy for screenshots).
//   npm run seed        ->  login: demo@example.com / demo1234
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const User = require('./models/User');
const Task = require('./models/Task');
const { addDays, resolveToday } = require('./utils/taskFilters');

const run = async () => {
  await connectDB();

  const email = 'demo@example.com';
  const existing = await User.findOne({ email });
  if (existing) {
    await Task.deleteMany({ user: existing.id });
    await existing.deleteOne();
  }

  const user = await User.create({ name: 'Demo Student', email, password: 'demo1234' });
  const today = resolveToday();
  const day = (n) => addDays(today, n);

  const tasks = [
    { title: 'Submit React assignment', description: 'Push the final code and README to GitHub.', status: 'in-progress', priority: 'high', dueDate: day(0) },
    { title: 'Fix login bug on mobile', description: 'Token is lost after a page refresh on Safari.', status: 'todo', priority: 'high', dueDate: day(-2) },
    { title: 'Read chapter on MongoDB indexes', status: 'todo', priority: 'medium', dueDate: day(2) },
    { title: 'Prepare demo for Friday', description: 'Register, add tasks, show the filters.', status: 'todo', priority: 'high', dueDate: day(3) },
    { title: 'Write unit tests for filters', status: 'in-progress', priority: 'medium', dueDate: day(5) },
    { title: 'Reply to mentor email', status: 'todo', priority: 'low', dueDate: day(-1) },
    { title: 'Set up MongoDB Atlas cluster', status: 'done', priority: 'medium', dueDate: day(-4) },
    { title: 'Design the database schema', status: 'done', priority: 'high', dueDate: day(-6) },
    { title: 'Tidy up the README', status: 'todo', priority: 'low' },
    { title: 'Plan next week', description: 'List the topics to revise.', status: 'todo', priority: 'medium', dueDate: day(8) }
  ];

  // Insert one by one so createdAt differs and "newest first" looks natural
  for (const t of tasks) {
    await Task.create({ ...t, user: user.id });
  }

  console.log(`Seeded ${tasks.length} tasks. Login: ${email} / demo1234`);
  await mongoose.disconnect();
};

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
