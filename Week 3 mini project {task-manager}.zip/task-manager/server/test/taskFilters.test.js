const test = require('node:test');
const assert = require('node:assert/strict');
const {
  isValidDate,
  addDays,
  resolveToday,
  escapeRegex,
  buildTaskFilter,
  sortTasks
} = require('../src/utils/taskFilters');

const USER = 'user123';
const TODAY = '2026-11-03';

test('isValidDate accepts real dates and rejects bad ones', () => {
  assert.equal(isValidDate('2026-11-03'), true);
  assert.equal(isValidDate('2028-02-29'), true); // leap year
  assert.equal(isValidDate('2026-02-30'), false);
  assert.equal(isValidDate('03/11/2026'), false);
  assert.equal(isValidDate(''), false);
  assert.equal(isValidDate(undefined), false);
});

test('addDays crosses month and year boundaries', () => {
  assert.equal(addDays('2026-11-03', 7), '2026-11-10');
  assert.equal(addDays('2026-12-30', 3), '2027-01-02');
  assert.equal(addDays('2026-03-01', -1), '2026-02-28');
});

test('resolveToday uses a valid client date, otherwise falls back to the server date', () => {
  assert.equal(resolveToday('2026-11-03'), '2026-11-03');
  assert.match(resolveToday('nonsense'), /^\d{4}-\d{2}-\d{2}$/);
  assert.match(resolveToday(undefined), /^\d{4}-\d{2}-\d{2}$/);
});

test('buildTaskFilter always scopes to the user', () => {
  assert.deepEqual(buildTaskFilter({}, USER), { user: USER });
});

test('buildTaskFilter applies status and priority, ignoring unknown values', () => {
  const f = buildTaskFilter({ status: 'in-progress', priority: 'high' }, USER);
  assert.equal(f.status, 'in-progress');
  assert.equal(f.priority, 'high');

  const ignored = buildTaskFilter({ status: 'hacked', priority: '$ne' }, USER);
  assert.deepEqual(ignored, { user: USER });
});

test('due=overdue means past due and unfinished', () => {
  const f = buildTaskFilter({ due: 'overdue', today: TODAY }, USER);
  assert.deepEqual(f.status, { $ne: 'done' });
  assert.deepEqual(f.dueDate, { $gt: '', $lt: TODAY });
});

test('due=overdue combined with status=done matches nothing', () => {
  const f = buildTaskFilter({ due: 'overdue', status: 'done', today: TODAY }, USER);
  assert.deepEqual(f.status, { $in: [] });
});

test('due=overdue respects an explicit status filter', () => {
  const f = buildTaskFilter({ due: 'overdue', status: 'todo', today: TODAY }, USER);
  assert.equal(f.status, 'todo');
});

test('due=today and due=week use the client date', () => {
  const t = buildTaskFilter({ due: 'today', today: TODAY }, USER);
  assert.equal(t.dueDate, TODAY);
  assert.deepEqual(t.status, { $ne: 'done' });

  const w = buildTaskFilter({ due: 'week', today: TODAY }, USER);
  assert.deepEqual(w.dueDate, { $gte: TODAY, $lte: '2026-11-10' });
});

test('search builds a case-insensitive regex on title and description', () => {
  const f = buildTaskFilter({ search: '  React  ' }, USER);
  assert.equal(f.$or.length, 2);
  assert.ok(f.$or[0].title.test('Finish the react project'));
  assert.ok(f.$or[1].description.test('REACT notes'));
});

test('search escapes regex characters so input cannot break or abuse the query', () => {
  assert.equal(escapeRegex('a.b(c)*'), 'a\\.b\\(c\\)\\*');
  const f = buildTaskFilter({ search: '(a+)+$' }, USER);
  assert.ok(f.$or[0].title.test('see (a+)+$ here'));
  assert.equal(f.$or[0].title.test('aaaa'), false);
});

test('blank search is ignored', () => {
  assert.deepEqual(buildTaskFilter({ search: '   ' }, USER), { user: USER });
});

// ---- sorting ----
const mk = (title, extra) => ({ title, priority: 'medium', dueDate: '', createdAt: '2026-11-01T10:00:00Z', ...extra });
const titles = (list) => list.map((t) => t.title);

test('sortTasks newest (default) and oldest', () => {
  const list = [
    mk('b', { createdAt: '2026-11-02T10:00:00Z' }),
    mk('a', { createdAt: '2026-11-01T10:00:00Z' }),
    mk('c', { createdAt: '2026-11-03T10:00:00Z' })
  ];
  assert.deepEqual(titles(sortTasks(list)), ['c', 'b', 'a']);
  assert.deepEqual(titles(sortTasks(list, 'newest')), ['c', 'b', 'a']);
  assert.deepEqual(titles(sortTasks(list, 'oldest')), ['a', 'b', 'c']);
});

test('sortTasks by due date puts undated tasks last', () => {
  const list = [
    mk('none'),
    mk('later', { dueDate: '2026-11-20' }),
    mk('soon', { dueDate: '2026-11-05' })
  ];
  assert.deepEqual(titles(sortTasks(list, 'due')), ['soon', 'later', 'none']);
});

test('sortTasks by priority orders high, medium, low', () => {
  const list = [mk('l', { priority: 'low' }), mk('h', { priority: 'high' }), mk('m', { priority: 'medium' })];
  assert.deepEqual(titles(sortTasks(list, 'priority')), ['h', 'm', 'l']);
});

test('sortTasks does not mutate the input array', () => {
  const list = [mk('b', { createdAt: '2026-11-02T10:00:00Z' }), mk('a', { createdAt: '2026-11-03T10:00:00Z' })];
  const copy = [...list];
  sortTasks(list, 'oldest');
  assert.deepEqual(list, copy);
});
