# Taskwise – Task Manager Application

A complete task tracking web app with **user login** and **task filtering**.

- **Frontend:** React (Vite) with React Router
- **Backend:** Express REST API
- **Database:** MongoDB (Mongoose)
- **Auth:** JSON Web Tokens, passwords hashed with bcrypt

Sign up, add tasks with a status, priority and due date, then narrow the list with filters, search and sorting. Counts in the sidebar show at a glance how much is due today or overdue.

## How the pieces connect

```
 React app (localhost:5173)          Express API (localhost:3000)          MongoDB
 ┌───────────────────────┐  HTTP    ┌──────────────────────────┐  Mongoose ┌──────────┐
 │ pages, components     │ ───────► │ routes → middleware →    │ ────────► │ users    │
 │ Axios + JWT in header │ ◄─────── │ controllers → models     │ ◄──────── │ tasks    │
 └───────────────────────┘   JSON   └──────────────────────────┘           └──────────┘
```

1. The user logs in; the API returns a JWT, which the React app stores and sends as `Authorization: Bearer <token>` on every request.
2. The `protect` middleware verifies the token and puts the user on `req.user`.
3. Every task query includes `user: req.user.id`, so each person only ever sees their own tasks.
4. Filters in the UI become query-string parameters; the API turns them into a MongoDB query.

## Features

- Register, log in, log out; the session survives a page refresh
- Add, edit, delete tasks; mark done with a checkbox or change status from a dropdown
- Each task has a **status** (To do, In progress, Done), **priority** (High, Medium, Low) and optional **due date**
- **Filtering** by due date (today, overdue, next 7 days), status, priority, and free-text search
- **Sorting** by newest, oldest, due date or priority
- Filters are stored in the URL (for example `/?view=overdue&priority=high`), so they survive a refresh and can be bookmarked
- Live counts in the sidebar for every filter
- Overdue tasks are highlighted; priority is shown as a coloured stripe on each task
- Responsive layout (sidebar becomes filter chips on phones)

## Project structure

```
task-manager/
├── README.md
├── package.json                 # convenience scripts (install:all, server, client, seed, test)
├── screenshots/                 # add your screenshots here
├── server/
│   ├── server.js
│   ├── .env.example
│   ├── postman/TaskManager-API.postman_collection.json
│   ├── test/taskFilters.test.js # unit tests for the filter logic
│   └── src/
│       ├── config/db.js
│       ├── models/              # User.js, Task.js
│       ├── middleware/          # auth.js (JWT), errorHandler.js
│       ├── controllers/         # authController.js, taskController.js
│       ├── routes/              # authRoutes.js, taskRoutes.js
│       ├── utils/taskFilters.js # builds the MongoDB filter, sorts tasks
│       └── seed.js              # demo account + sample tasks
└── client/
    ├── index.html
    ├── vite.config.js           # dev proxy to the API
    └── src/
        ├── main.jsx, App.jsx, api.js, styles.css
        ├── context/AuthContext.jsx
        ├── utils/dates.js
        ├── components/          # Sidebar, TaskRow, TaskModal, AuthLayout, RouteGuards, Logo
        └── pages/               # Dashboard, Login, Register, NotFound
```

## Getting started

### Prerequisites

- Node.js 18 or newer
- MongoDB running locally, **or** a free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster

### 1. Install

```bash
git clone <your-repo-url>
cd task-manager
npm run install:all
```

### 2. Configure the server

```bash
cd server
cp .env.example .env        # on Windows: copy .env.example .env
```

Open `server/.env` and set:

- `MONGODB_URI`: local MongoDB or your Atlas connection string
- `JWT_SECRET`: any long random string. Generate one with:
  `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`

The client needs no configuration in development.

### 3. (Optional) Load demo data

```bash
npm run seed
```

This creates a demo account, **demo@example.com / demo1234**, with ten sample tasks (some overdue, some due today) so you can try the filters straight away.

### 4. Run (two terminals, from the project root)

```bash
# Terminal 1: API on http://localhost:3000
npm run server

# Terminal 2: React app on http://localhost:5173
npm run client
```

Open **http://localhost:5173**.

> In development Vite proxies `/api` to the Express server, so there are no CORS or URL settings to change.

## API reference

Base URL: `http://localhost:3000`. All routes except register and login need the header
`Authorization: Bearer <token>`.

### Auth

| Method | Endpoint | Description | Success |
|---|---|---|---|
| POST | `/api/auth/register` | Create account `{ name, email, password }` | 201 `{ token, user }` |
| POST | `/api/auth/login` | Log in `{ email, password }` | 200 `{ token, user }` |
| GET | `/api/auth/me` | Current user | 200 `{ user }` |

### Tasks

| Method | Endpoint | Description | Success |
|---|---|---|---|
| GET | `/api/tasks` | List my tasks (supports filters below) | 200 |
| GET | `/api/tasks/stats` | Counts used by the sidebar | 200 |
| GET | `/api/tasks/:id` | Get one task | 200 |
| POST | `/api/tasks` | Add a task | 201 |
| PUT | `/api/tasks/:id` | Update (only the fields you send) | 200 |
| DELETE | `/api/tasks/:id` | Delete | 204 |

Task JSON:

```json
{
  "title": "Submit React assignment",
  "description": "Push the final code and README to GitHub.",
  "status": "in-progress",
  "priority": "high",
  "dueDate": "2026-11-05"
}
```

`status` is `todo`, `in-progress` or `done`. `priority` is `low`, `medium` or `high`. `dueDate` is `YYYY-MM-DD` or an empty string.

### Filter parameters for `GET /api/tasks`

| Parameter | Values | Meaning |
|---|---|---|
| `status` | `todo`, `in-progress`, `done` | Only tasks with this status |
| `priority` | `low`, `medium`, `high` | Only tasks with this priority |
| `due` | `today`, `overdue`, `week` | Unfinished tasks due today, past due, or due within 7 days |
| `search` | any text | Matches title or notes, case-insensitive |
| `sort` | `newest` (default), `oldest`, `due`, `priority` | Sort order |
| `today` | `YYYY-MM-DD` | The client's local date, so "today" matches the user's time zone |

Parameters can be combined, for example `/api/tasks?status=todo&priority=high&due=week&sort=due`. Unknown values are ignored.

Errors: `400` validation, `401` missing or invalid token, `404` not found, `409` email already registered.

### Design notes

- **Due dates are `YYYY-MM-DD` strings**, not `Date` objects. That avoids time-zone bugs: "due today" is the same calendar day for the user and the server, and these strings compare correctly.
- **Filter logic lives in one pure module** (`server/src/utils/taskFilters.js`) with no database dependency, which is why it is easy to unit test.
- The search text is **regex-escaped** before it reaches MongoDB, so special characters cannot break or abuse the query.

## Testing

**Unit tests** (no database needed):

```bash
npm test
```

They cover date validation, "today / week / overdue" boundaries, regex escaping and all sort orders.

**Postman:** import `server/postman/TaskManager-API.postman_collection.json`, start the server, and run the folders in order: **Auth → Tasks (CRUD) → Filtering → Cleanup**. The login request saves the token automatically.

## Uploading to GitHub

### Option 1: A new repository

Create an empty repository on github.com (no README), then from the project root:

```bash
git init
git add .
git commit -m "Task Manager: React, Express, MongoDB, JWT auth and task filtering"
git branch -M main
git remote add origin https://github.com/<your-username>/task-manager.git
git push -u origin main
```

### Option 2: A folder inside an existing repository

```bash
git clone https://github.com/<your-username>/<existing-repo>.git
cd <existing-repo>
# copy the task-manager folder in here, then:
git add task-manager
git commit -m "Add Task Manager mini project"
git push
```

Do not run `git init` inside the copied folder; that creates a repository inside a repository.

`.gitignore` keeps `node_modules` and your `.env` (database credentials and JWT secret) out of the repo. Run `git status` before committing and confirm no `.env` file is listed. After pushing, add screenshots to the `screenshots/` folder.

## Troubleshooting

| Problem | Fix |
|---|---|
| `MongoDB connection failed` | Start MongoDB, or check `MONGODB_URI` (Atlas: allow your IP under Network Access) |
| `Missing JWT_SECRET` | Create `server/.env` from `.env.example` |
| The app keeps returning to the login page | The token is invalid or expired; log in again. Also check `JWT_SECRET` did not change |
| `Cannot reach the server` | Make sure the API is running on port 3000 |
| Port already in use | Change `PORT` in `server/.env` **and** the proxy target in `client/vite.config.js` |

## Ideas for extending it

- Pagination for very long task lists
- Rate limiting on the login route
- Drag-and-drop board view by status
- Password reset by email
- Deploy the API (Render, Railway) and the client (Netlify, Vercel); set `CLIENT_URL` on the API and `VITE_API_URL` when building the client

## License

MIT
